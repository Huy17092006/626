let last=0;const hdr=document.getElementById('hdr');
  addEventListener('scroll',()=>{const y=scrollY;hdr.style.transform=(y>last&&y>200)?'translateY(-100%)':'translateY(0)';last=y;});
  const burger=document.getElementById('burger'),menu=document.getElementById('menu');
  burger.addEventListener('click',()=>menu.classList.toggle('show'));
  menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>menu.classList.remove('show')));
  const e=document.getElementById('embers');
  for(let i=0;i<30;i++){const s=document.createElement('i');s.style.left=Math.random()*100+'%';s.style.animationDuration=(6+Math.random()*8)+'s';s.style.animationDelay=(Math.random()*8)+'s';s.style.opacity=Math.random();e.appendChild(s);}
  const acc=document.getElementById('acc');
  acc.querySelectorAll('.acc-item').forEach(it=>{const go=()=>{acc.querySelectorAll('.acc-item').forEach(x=>x.classList.remove('active'));it.classList.add('active');};it.addEventListener('mouseenter',go);it.addEventListener('click',go);});
  document.querySelectorAll('.tab').forEach(t=>t.addEventListener('click',()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('on'));document.querySelectorAll('.panel').forEach(p=>p.classList.remove('on'));t.classList.add('on');document.querySelector('.panel[data-panel="'+t.dataset.tab+'"]').classList.add('on');}));
  document.querySelectorAll('img').forEach(im=>im.addEventListener('error',()=>im.style.opacity=0));
  const io=new IntersectionObserver(es=>es.forEach(en=>{if(en.isIntersecting){en.target.classList.add('in');io.unobserve(en.target);}}),{threshold:.16});
  document.querySelectorAll('.reveal').forEach(el=>io.observe(el));